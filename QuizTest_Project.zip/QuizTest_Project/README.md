# spring-security-authorization
Sample Project for Spring Security Role-based Authorization
### Follow our written tutorial here: [Spring Boot Security Role-based Authorization Tutorial](https://www.codejava.net/frameworks/spring-boot/spring-boot-security-role-based-authorization-tutorial)
### Watch coding in action on YouTube: [Spring Boot Security Role-based Authorization Tutorial](https://youtu.be/i21h6ThUiWc)
## Learn more about Spring framework:
### [Spring Framework Tutorials](https://www.codejava.net/spring-tutorials)
### [Spring Boot Tutorials](https://www.codejava.net/spring-boot-tutorials)
### [Spring Security Tutorials](https://www.codejava.net/spring-security-tutorials)
## Learn to Build a Real-life Shopping Webapp using Java Spring Boot, Thymeleaf, Bootstrap, jQuery and HTML:
### [Spring Boot E-Commerce Ultimate Course](https://www.udemy.com/course/spring-boot-e-commerce-ultimate/?referralCode=3A24FAC7220029CEDFD6)
